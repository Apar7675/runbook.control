# RunBook Control compact overview v1

Supervisor-authored reference, tokens and native CSS layout. Reuse existing branding and native components; no new photo, illustration, icon or standalone asset is required. Reference PNG/HTML are comparison documents, never app assets. No WPF or Desktop redesign applies here.

Owner request Oct16: panels oversized, constant scrolling. Fit key overview on desktop while retaining clear type, complete routes and access to details. Current request authorizes this bounded Control UI task; pause stays for unrelated work. Office C primary, LOCAL checkpoint only: GitHub push/cost gate CLOSED. Local ZIP delivery follows newer owner C-primary/cost direction, superseding historical GitHub ZIP dispatch for this task only.

Map: header -> title/refresh; four compact priority metrics -> existing attention counts; summary strip -> other five existing counts; attention queue + health -> main two-column row; three compact recent entries -> audit; support/updates/audit -> shortcut row. Preserve all13 sidebar destinations, statuses, user and role.

At desktop >=1200px wide and >=720px high aim overview without page scroll at100%zoom; verify1366x768 and1440x900. Narrow screens/large zoom allow natural vertical scroll. No body overflow:hidden, fixed clipped content, tiny text, CSS zoom or scaled page. Sidebar border-box prevents padding overflow. Scoped compact variants; preserve unrelated modules.

Critical: buildAlerts currently slices12 before priority ordering. Keep ALL generated alerts, order Critical/High/Medium/Low before preview4. Clearly counted Show all alerts details disclosure exposes ALL generated rows, full details/source and working review links; keyboard accessible. Activity full list via audit log. Limited query counts cannot claim unlimited global totals: qualify limits when reached. Avoid duplicated metrics. Existing fetch/auth/permissions/entitlement remain server-owned; preserve truthful empty/restricted/error semantics; no fake production data.

Synthetic values illustrative only. Verify actual React components in local-only fixture harness outside deployable src routes; external network BLOCKED. Capture populated, empty, large-count and long-label states. No auth bypass, session copying, credential request, real data, live sends/payments/migrations. No main merge, push, hosted CI, paid services or API billing. Supervisor handles preview deploy after review.
